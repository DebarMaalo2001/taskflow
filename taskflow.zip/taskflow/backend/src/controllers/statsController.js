const Task = require('../models/Task');
const Project = require('../models/Project');

// @GET /api/stats/overview
exports.getOverview = async (req, res) => {
  try {
    const userId = req.user._id;

    // Get user's projects
    const projects = await Project.find({
      $or: [{ owner: userId }, { members: userId }],
    }).select('_id');
    const projectIds = projects.map((p) => p._id);

    // Task stats
    const [totalTasks, tasksByStatus, tasksByPriority, overdueCount] = await Promise.all([
      Task.countDocuments({ project: { $in: projectIds } }),

      Task.aggregate([
        { $match: { project: { $in: projectIds } } },
        { $group: { _id: '$status', count: { $sum: 1 } } },
      ]),

      Task.aggregate([
        { $match: { project: { $in: projectIds } } },
        { $group: { _id: '$priority', count: { $sum: 1 } } },
      ]),

      Task.countDocuments({
        project: { $in: projectIds },
        dueDate: { $lt: new Date() },
        status: { $ne: 'done' },
      }),
    ]);

    // Tasks completed last 7 days (daily)
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

    const completedByDay = await Task.aggregate([
      {
        $match: {
          project: { $in: projectIds },
          status: 'done',
          completedAt: { $gte: sevenDaysAgo },
        },
      },
      {
        $group: {
          _id: { $dateToString: { format: '%Y-%m-%d', date: '$completedAt' } },
          count: { $sum: 1 },
        },
      },
      { $sort: { _id: 1 } },
    ]);

    // Project activity
    const projectStats = await Task.aggregate([
      { $match: { project: { $in: projectIds } } },
      {
        $group: {
          _id: '$project',
          total: { $sum: 1 },
          done: { $sum: { $cond: [{ $eq: ['$status', 'done'] }, 1, 0] } },
        },
      },
      {
        $lookup: { from: 'projects', localField: '_id', foreignField: '_id', as: 'project' },
      },
      { $unwind: '$project' },
      {
        $project: {
          name: '$project.name',
          color: '$project.color',
          total: 1,
          done: 1,
          progress: {
            $cond: [
              { $eq: ['$total', 0] },
              0,
              { $multiply: [{ $divide: ['$done', '$total'] }, 100] },
            ],
          },
        },
      },
    ]);

    res.json({
      success: true,
      data: {
        totalProjects: projects.length,
        totalTasks,
        overdueCount,
        tasksByStatus: Object.fromEntries(tasksByStatus.map((s) => [s._id, s.count])),
        tasksByPriority: Object.fromEntries(tasksByPriority.map((p) => [p._id, p.count])),
        completedByDay,
        projectStats,
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
