import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { statsAPI } from '../api/services';
import { useAuth } from '../context/AuthContext';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line,
} from 'recharts';
import './DashboardPage.css';

const STATUS_COLORS = {
  todo: '#555b6e', in_progress: '#60a5fa', review: '#fbbf24', done: '#22d3a0',
};
const PRIORITY_COLORS = {
  low: '#555b6e', medium: '#60a5fa', high: '#fbbf24', urgent: '#f87171',
};

const StatCard = ({ label, value, sub, color }) => (
  <div className="stat-card card fade-up">
    <div className="stat-value" style={{ color }}>{value}</div>
    <div className="stat-label">{label}</div>
    {sub && <div className="stat-sub">{sub}</div>}
  </div>
);

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload?.length) {
    return (
      <div className="chart-tooltip">
        <p className="tt-label">{label}</p>
        {payload.map((p, i) => (
          <p key={i} style={{ color: p.color }}>{p.name}: <strong>{p.value}</strong></p>
        ))}
      </div>
    );
  }
  return null;
};

export default function DashboardPage() {
  const { user } = useAuth();
  const { data, isLoading } = useQuery({
    queryKey: ['stats'],
    queryFn: () => statsAPI.getOverview().then(r => r.data.data),
  });

  if (isLoading) return (
    <div className="page-loading"><div className="spinner" /></div>
  );

  const s = data || {};
  const statusData = Object.entries(s.tasksByStatus || {}).map(([name, value]) => ({ name, value }));
  const priorityData = Object.entries(s.tasksByPriority || {}).map(([name, value]) => ({ name, value }));
  const completedData = (s.completedByDay || []).map(d => ({
    day: d._id?.slice(5),
    tasks: d.count,
  }));

  const doneTasks = s.tasksByStatus?.done || 0;
  const total = s.totalTasks || 0;
  const completionRate = total > 0 ? Math.round((doneTasks / total) * 100) : 0;

  return (
    <div className="dashboard fade-up">
      <div className="page-header">
        <div>
          <h1 className="page-title">Good {greeting()}, {user?.name?.split(' ')[0]} 👋</h1>
          <p className="page-sub">Here's what's happening across your workspace</p>
        </div>
      </div>

      {/* Stat cards */}
      <div className="stats-grid">
        <StatCard label="Total Projects" value={s.totalProjects ?? 0} color="var(--accent2)" />
        <StatCard label="Total Tasks" value={total} color="var(--blue)" />
        <StatCard label="Completed" value={doneTasks} sub={`${completionRate}% completion rate`} color="var(--green)" />
        <StatCard label="Overdue" value={s.overdueCount ?? 0} color={s.overdueCount > 0 ? 'var(--red)' : 'var(--text2)'} sub={s.overdueCount > 0 ? 'Needs attention' : 'All on track'} />
      </div>

      {/* Charts row */}
      <div className="charts-grid">
        <div className="card chart-card">
          <h3 className="chart-title">Tasks completed (last 7 days)</h3>
          {completedData.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={completedData}>
                <XAxis dataKey="day" stroke="var(--text3)" tick={{ fontSize: 12 }} />
                <YAxis stroke="var(--text3)" tick={{ fontSize: 12 }} allowDecimals={false} />
                <Tooltip content={<CustomTooltip />} />
                <Line type="monotone" dataKey="tasks" stroke="var(--accent)" strokeWidth={2.5} dot={{ fill: 'var(--accent)', r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          ) : <div className="empty-chart">No completed tasks in last 7 days</div>}
        </div>

        <div className="card chart-card">
          <h3 className="chart-title">Tasks by status</h3>
          {statusData.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={statusData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={75} paddingAngle={3}>
                  {statusData.map((entry) => (
                    <Cell key={entry.name} fill={STATUS_COLORS[entry.name] || '#888'} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          ) : <div className="empty-chart">No tasks yet</div>}
          <div className="legend">
            {statusData.map(d => (
              <span key={d.name} className="legend-item">
                <span className="legend-dot" style={{ background: STATUS_COLORS[d.name] }} />
                {d.name.replace('_', ' ')} ({d.value})
              </span>
            ))}
          </div>
        </div>

        <div className="card chart-card">
          <h3 className="chart-title">Tasks by priority</h3>
          {priorityData.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={priorityData} barSize={28}>
                <XAxis dataKey="name" stroke="var(--text3)" tick={{ fontSize: 12 }} />
                <YAxis stroke="var(--text3)" tick={{ fontSize: 12 }} allowDecimals={false} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                  {priorityData.map(entry => (
                    <Cell key={entry.name} fill={PRIORITY_COLORS[entry.name] || '#888'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : <div className="empty-chart">No tasks yet</div>}
        </div>
      </div>

      {/* Project progress */}
      {s.projectStats?.length > 0 && (
        <div className="card">
          <h3 className="chart-title" style={{ marginBottom: 20 }}>Project progress</h3>
          <div className="project-progress-list">
            {s.projectStats.map(p => (
              <div key={p._id} className="project-progress-item">
                <div className="pp-header">
                  <div className="pp-dot" style={{ background: p.color }} />
                  <span className="pp-name">{p.name}</span>
                  <span className="pp-count">{p.done}/{p.total} tasks</span>
                  <span className="pp-pct">{Math.round(p.progress)}%</span>
                </div>
                <div className="progress-bar-bg">
                  <div className="progress-bar-fill" style={{ width: `${p.progress}%`, background: p.color }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function greeting() {
  const h = new Date().getHours();
  if (h < 12) return 'morning';
  if (h < 18) return 'afternoon';
  return 'evening';
}
