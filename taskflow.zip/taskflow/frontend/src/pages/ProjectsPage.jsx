import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { projectsAPI } from '../api/services';
import Modal from '../components/Modal';
import './ProjectsPage.css';

const COLORS = ['#7c6af7','#22d3a0','#60a5fa','#fbbf24','#f87171','#f472b6','#a78bfa','#34d399'];

const statusLabel = { active: 'Active', completed: 'Completed', archived: 'Archived' };

export default function ProjectsPage() {
  const qc = useQueryClient();
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ name: '', description: '', color: COLORS[0], status: 'active' });

  const { data, isLoading } = useQuery({
    queryKey: ['projects'],
    queryFn: () => projectsAPI.getAll().then(r => r.data.data),
  });

  const createMutation = useMutation({
    mutationFn: projectsAPI.create,
    onSuccess: () => { qc.invalidateQueries(['projects']); qc.invalidateQueries(['stats']); setShowModal(false); resetForm(); },
  });

  const deleteMutation = useMutation({
    mutationFn: projectsAPI.delete,
    onSuccess: () => { qc.invalidateQueries(['projects']); qc.invalidateQueries(['stats']); },
  });

  const resetForm = () => setForm({ name: '', description: '', color: COLORS[0], status: 'active' });

  const handleCreate = (e) => {
    e.preventDefault();
    createMutation.mutate(form);
  };

  return (
    <div className="projects-page fade-up">
      <div className="page-header">
        <div>
          <h1 className="page-title">Projects</h1>
          <p className="page-sub">{data?.length || 0} projects in your workspace</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>+ New Project</button>
      </div>

      {isLoading ? (
        <div className="page-loading"><div className="spinner" /></div>
      ) : data?.length === 0 ? (
        <div className="empty-state card">
          <div className="empty-icon">◈</div>
          <h3>No projects yet</h3>
          <p>Create your first project to start organizing tasks</p>
          <button className="btn btn-primary" onClick={() => setShowModal(true)}>+ New Project</button>
        </div>
      ) : (
        <div className="projects-grid">
          {data.map(project => (
            <div key={project._id} className="project-card card">
              <div className="project-card-header">
                <div className="project-dot" style={{ background: project.color }} />
                <span className={`badge badge-${project.status}`}>{statusLabel[project.status]}</span>
                <button
                  className="btn btn-danger icon-btn"
                  onClick={() => { if (window.confirm('Delete this project and all its tasks?')) deleteMutation.mutate(project._id); }}
                  title="Delete"
                >✕</button>
              </div>
              <Link to={`/projects/${project._id}`}>
                <h3 className="project-name">{project.name}</h3>
              </Link>
              {project.description && <p className="project-desc">{project.description}</p>}
              <div className="project-meta">
                <span className="meta-item">📋 {project.taskCount ?? 0} tasks</span>
                {project.dueDate && (
                  <span className="meta-item">📅 {new Date(project.dueDate).toLocaleDateString()}</span>
                )}
              </div>
              <Link to={`/projects/${project._id}`} className="btn btn-ghost open-btn">Open →</Link>
            </div>
          ))}
        </div>
      )}

      <Modal open={showModal} onClose={() => { setShowModal(false); resetForm(); }} title="New Project">
        <form onSubmit={handleCreate} className="form">
          <div className="field">
            <label>Project Name *</label>
            <input
              placeholder="e.g. Website Redesign"
              value={form.name}
              onChange={e => setForm({ ...form, name: e.target.value })}
              required
            />
          </div>
          <div className="field">
            <label>Description</label>
            <textarea
              rows={3}
              placeholder="What is this project about?"
              value={form.description}
              onChange={e => setForm({ ...form, description: e.target.value })}
            />
          </div>
          <div className="field">
            <label>Color</label>
            <div className="color-picker">
              {COLORS.map(c => (
                <button key={c} type="button"
                  className={`color-dot ${form.color === c ? 'selected' : ''}`}
                  style={{ background: c }}
                  onClick={() => setForm({ ...form, color: c })}
                />
              ))}
            </div>
          </div>
          <div className="field">
            <label>Due Date</label>
            <input type="date" value={form.dueDate || ''} onChange={e => setForm({ ...form, dueDate: e.target.value })} />
          </div>
          <div className="form-actions">
            <button type="button" className="btn btn-ghost" onClick={() => { setShowModal(false); resetForm(); }}>Cancel</button>
            <button type="submit" className="btn btn-primary" disabled={createMutation.isPending}>
              {createMutation.isPending ? 'Creating...' : 'Create Project'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
