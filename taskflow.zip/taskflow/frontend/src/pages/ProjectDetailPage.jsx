import React from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { projectsAPI } from '../api/services';
import TasksPage from './TasksPage';
import './ProjectDetailPage.css';

export default function ProjectDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const qc = useQueryClient();

  const { data: project, isLoading } = useQuery({
    queryKey: ['project', id],
    queryFn: () => projectsAPI.getOne(id).then(r => r.data.data),
  });

  const updateMutation = useMutation({
    mutationFn: (data) => projectsAPI.update(id, data),
    onSuccess: () => qc.invalidateQueries(['project', id]),
  });

  if (isLoading) return <div className="page-loading"><div className="spinner" /></div>;
  if (!project) return <div>Project not found</div>;

  return (
    <div className="project-detail fade-up">
      <div className="breadcrumb">
        <Link to="/projects">Projects</Link>
        <span className="bc-sep">›</span>
        <span>{project.name}</span>
      </div>

      <div className="project-detail-header card">
        <div className="pdh-left">
          <div className="pdh-dot" style={{ background: project.color }} />
          <div>
            <h1 className="project-detail-name">{project.name}</h1>
            {project.description && <p className="project-detail-desc">{project.description}</p>}
          </div>
        </div>
        <div className="pdh-right">
          <select
            value={project.status}
            onChange={e => updateMutation.mutate({ status: e.target.value })}
            className="status-select"
          >
            {['active', 'completed', 'archived'].map(s => (
              <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>
            ))}
          </select>
          <div className="pdh-meta">
            <span>Created {new Date(project.createdAt).toLocaleDateString()}</span>
            {project.dueDate && <span>Due {new Date(project.dueDate).toLocaleDateString()}</span>}
          </div>
        </div>
      </div>

      <TasksPage projectId={id} />
    </div>
  );
}
