import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { tasksAPI, projectsAPI } from '../api/services';
import { useAuth } from '../context/AuthContext';
import Modal from '../components/Modal';
import { format } from 'date-fns';
import './TasksPage.css';

const STATUSES = ['todo', 'in_progress', 'review', 'done'];
const PRIORITIES = ['low', 'medium', 'high', 'urgent'];

export default function TasksPage({ projectId }) {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [showModal, setShowModal] = useState(false);
  const [editTask, setEditTask] = useState(null);
  const [filters, setFilters] = useState({ status: '', priority: '' });
  const [form, setForm] = useState(defaultForm(projectId));

  const params = { ...(projectId ? { project: projectId } : {}), ...Object.fromEntries(Object.entries(filters).filter(([,v]) => v)) };

  const { data: tasks, isLoading } = useQuery({
    queryKey: ['tasks', params],
    queryFn: () => tasksAPI.getAll(params).then(r => r.data.data),
  });

  const { data: projects } = useQuery({
    queryKey: ['projects'],
    queryFn: () => projectsAPI.getAll().then(r => r.data.data),
    enabled: !projectId,
  });

  const createMutation = useMutation({
    mutationFn: tasksAPI.create,
    onSuccess: () => { qc.invalidateQueries(['tasks']); qc.invalidateQueries(['stats']); closeModal(); },
  });
  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => tasksAPI.update(id, data),
    onSuccess: () => { qc.invalidateQueries(['tasks']); qc.invalidateQueries(['stats']); closeModal(); },
  });
  const deleteMutation = useMutation({
    mutationFn: tasksAPI.delete,
    onSuccess: () => { qc.invalidateQueries(['tasks']); qc.invalidateQueries(['stats']); },
  });

  const closeModal = () => { setShowModal(false); setEditTask(null); setForm(defaultForm(projectId)); };

  const openEdit = (task) => {
    setEditTask(task);
    setForm({
      title: task.title,
      description: task.description || '',
      project: task.project?._id || task.project || projectId || '',
      status: task.status,
      priority: task.priority,
      dueDate: task.dueDate ? task.dueDate.slice(0, 10) : '',
    });
    setShowModal(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editTask) updateMutation.mutate({ id: editTask._id, data: form });
    else createMutation.mutate(form);
  };

  const handleStatusChange = (taskId, status) => {
    updateMutation.mutate({ id: taskId, data: { status } });
  };

  return (
    <div className="tasks-page fade-up">
      <div className="page-header">
        <div>
          <h1 className="page-title">{projectId ? 'Tasks' : 'All Tasks'}</h1>
          <p className="page-sub">{tasks?.length || 0} tasks found</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>+ New Task</button>
      </div>

      {/* Filters */}
      <div className="filters-bar">
        <select value={filters.status} onChange={e => setFilters({ ...filters, status: e.target.value })} style={{ width: 'auto' }}>
          <option value="">All Status</option>
          {STATUSES.map(s => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
        </select>
        <select value={filters.priority} onChange={e => setFilters({ ...filters, priority: e.target.value })} style={{ width: 'auto' }}>
          <option value="">All Priority</option>
          {PRIORITIES.map(p => <option key={p} value={p}>{p}</option>)}
        </select>
        {(filters.status || filters.priority) && (
          <button className="btn btn-ghost" onClick={() => setFilters({ status: '', priority: '' })}>Clear</button>
        )}
      </div>

      {isLoading ? (
        <div className="page-loading"><div className="spinner" /></div>
      ) : tasks?.length === 0 ? (
        <div className="empty-state card">
          <div className="empty-icon">◇</div>
          <h3>No tasks found</h3>
          <p>Create your first task to get started</p>
          <button className="btn btn-primary" onClick={() => setShowModal(true)}>+ New Task</button>
        </div>
      ) : (
        <div className="tasks-list">
          {tasks.map(task => (
            <div key={task._id} className="task-row card">
              <div className="task-row-left">
                <button
                  className={`status-toggle ${task.status === 'done' ? 'done' : ''}`}
                  onClick={() => handleStatusChange(task._id, task.status === 'done' ? 'todo' : 'done')}
                  title="Toggle done"
                >
                  {task.status === 'done' ? '✓' : '○'}
                </button>
                <div className="task-info">
                  <div className={`task-title ${task.status === 'done' ? 'strikethrough' : ''}`}>{task.title}</div>
                  {task.description && <div className="task-desc">{task.description}</div>}
                  <div className="task-meta">
                    {task.project && !projectId && (
                      <span className="meta-dot" style={{ background: task.project.color }} title={task.project.name} />
                    )}
                    {task.dueDate && (
                      <span className={`meta-item ${isPast(task.dueDate) && task.status !== 'done' ? 'overdue' : ''}`}>
                        📅 {format(new Date(task.dueDate), 'MMM d')}
                      </span>
                    )}
                    {task.assignee && <span className="meta-item">👤 {task.assignee.name}</span>}
                  </div>
                </div>
              </div>
              <div className="task-row-right">
                <span className={`badge badge-${task.priority}`}>{task.priority}</span>
                <select
                  value={task.status}
                  onChange={e => handleStatusChange(task._id, e.target.value)}
                  className="status-select"
                >
                  {STATUSES.map(s => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
                </select>
                <button className="btn btn-ghost icon-btn" onClick={() => openEdit(task)}>✎</button>
                <button className="btn btn-danger icon-btn" onClick={() => { if (window.confirm('Delete this task?')) deleteMutation.mutate(task._id); }}>✕</button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal open={showModal} onClose={closeModal} title={editTask ? 'Edit Task' : 'New Task'}>
        <form onSubmit={handleSubmit} className="form">
          <div className="field">
            <label>Title *</label>
            <input placeholder="What needs to be done?" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} required />
          </div>
          <div className="field">
            <label>Description</label>
            <textarea rows={2} placeholder="Add more details..." value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />
          </div>
          {!projectId && (
            <div className="field">
              <label>Project *</label>
              <select value={form.project} onChange={e => setForm({ ...form, project: e.target.value })} required>
                <option value="">Select project</option>
                {projects?.map(p => <option key={p._id} value={p._id}>{p.name}</option>)}
              </select>
            </div>
          )}
          <div className="form-row">
            <div className="field">
              <label>Status</label>
              <select value={form.status} onChange={e => setForm({ ...form, status: e.target.value })}>
                {STATUSES.map(s => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
              </select>
            </div>
            <div className="field">
              <label>Priority</label>
              <select value={form.priority} onChange={e => setForm({ ...form, priority: e.target.value })}>
                {PRIORITIES.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
          </div>
          <div className="field">
            <label>Due Date</label>
            <input type="date" value={form.dueDate} onChange={e => setForm({ ...form, dueDate: e.target.value })} />
          </div>
          <div className="form-actions">
            <button type="button" className="btn btn-ghost" onClick={closeModal}>Cancel</button>
            <button type="submit" className="btn btn-primary" disabled={createMutation.isPending || updateMutation.isPending}>
              {editTask ? 'Save Changes' : 'Create Task'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

function defaultForm(projectId) {
  return { title: '', description: '', project: projectId || '', status: 'todo', priority: 'medium', dueDate: '' };
}

function isPast(date) {
  return new Date(date) < new Date();
}
